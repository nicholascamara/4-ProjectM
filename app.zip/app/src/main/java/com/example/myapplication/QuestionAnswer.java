package com.example.myapplication;

public class QuestionAnswer {
    public static String[] question ={
            "What is the capital of NJ",
            "What is the best school in NJ",
            "Which one is not the programming language?",
            "Which Hockey team is the best?",
            "What year are we in?",
            "Who owns Tesla?",
            "Who created FaceBook?",
            "Who is the best soccer player in the world?",
            "Who made apple?",
            "What does www stand for"
    };

    public static String[][] choices = {
            {"Trenton","Newark","Harrison","Bronx"},
            {"Rutgers","NJIT","MSU","TCNJ"},
            {"Java","Fluffy","C++","Python"},
            {"Rangers","Flyers","Islanders","Devils"},
            {"2023","2024","2021","3000"},
            {"Jake from state-farm", "Lebron James", "Elon Musk", "Bruce Lee"},
            {"Mark Zuckerberg","Jake Allen","SpongeBob", "Patrick Star"},
            {"Messi","Cristiano Ronaldo","ishowspeed","Neymar"},
            {"Steve Jobs","Donald Trump","J-Lo","Justin Bieber"},
            {"Word Wide Wrestling","Wrestling World Wide","Win Win Win", "World Wide Web"}

    };
    public static String[] correctAnswers = {
            "Trenton",
            "MSU",
            "Fluffy",
            "Devils",
            "2024",
            "Elon Musk",
            "Mark Zuckerberg",
            "Cristiano Ronaldo",
            "Steve Jobs",
            "World Wide Web"
    };
}
